import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
import org.openqa.selenium.Keys

// ---------- Helpers ----------
TestObject byCss(String css) {
	TestObject to = new TestObject(css)
	to.addProperty("css", ConditionType.EQUALS, css)
	return to
}
TestObject byXpath(String xp) {
	TestObject to = new TestObject(xp)
	to.addProperty("xpath", ConditionType.EQUALS, xp)
	return to
}

// ---------- Test Data (mock) ----------
String baseUrl          = "https://mock-iwms.local/requests"
String serviceRequestId = "SR-243"
String srTitle          = "Loose electrical wires near park"
String reminderNote     = "Reminder for assigned users on SR-243"
String newDescription   = "Updated description via automated test"
String assetToSelect    = "Pipe Cutter - PC-1001"
String attachmentPath   = "C:\\Temp\\mock-attachment.png"

// ---------- Page Objects (mock) ----------
def po = [
	headerSrDropdown     : byCss("[data-testid='sr-selector'] .dropdown-toggle"),
	headerSrCurrent      : byXpath("//h1[contains(.,'SR-243') or contains(.,'Loose electrical wires near park')]"),
	btnAddNew            : byCss("[data-testid='btn-add-new']"),
	btnNextAction        : byCss("[data-testid='btn-next-action']"),
	nextActionMenu       : byCss("[data-testid='menu-next-action']"),
	linkRequestedUsers   : byCss("[data-testid='requested-users-link']"),

	descriptionText      : byCss("[data-testid='sr-description']"),
	descriptionEditIcon  : byCss("[data-testid='sr-description'] [data-testid='icon-edit']"),
	descriptionEditor    : byCss("[data-testid='description-editor'] textarea"),
	descriptionSave      : byCss("[data-testid='description-editor'] [data-testid='btn-save']"),

	sendReminderIcon     : byCss("[data-testid='btn-send-reminder']"),
	sendReminderDialog   : byCss("[data-testid='dlg-reminder']"),
	sendReminderNote     : byCss("[data-testid='dlg-reminder'] textarea[name='note']"),
	sendReminderSubmit   : byCss("[data-testid='dlg-reminder'] [data-testid='btn-submit']"),

	relationsAddIcon     : byCss("[data-testid='relations'] [data-testid='icon-add']"),
	relationsDialog      : byCss("[data-testid='dlg-relations']"),

	tabOverview          : byCss("[data-testid='tab-overview']"),
	tabWork              : byCss("[data-testid='tab-work']"),
	tabCost              : byCss("[data-testid='tab-cost']"),
	tabDivision          : byCss("[data-testid='tab-division']"),

	sectionLocationSpace : byCss("[data-testid='section-location-space']"),
	mapCanvasPrimary     : byCss("[data-testid='section-location-space'] canvas, [data-testid='section-location-space'] .map"),
	btnAddLocation       : byCss("[data-testid='section-location-space'] [data-testid='icon-add-location']"),
	addLocationDialog    : byCss("[data-testid='dlg-add-location']"),
	addLocationInput     : byCss("[data-testid='dlg-add-location'] input[name='location']"),
	addLocationSave      : byCss("[data-testid='dlg-add-location'] [data-testid='btn-save']"),

	sectionAssets        : byCss("[data-testid='section-assets']"),
	btnAddAsset          : byCss("[data-testid='section-assets'] [data-testid='btn-add-asset']"),
	assetPickerDialog    : byCss("[data-testid='dlg-asset-picker']"),
	assetPickerSearch    : byCss("[data-testid='dlg-asset-picker'] input[type='search']"),
	assetPickerOption    : { String name -> byXpath("//div[@data-testid='dlg-asset-picker']//li[normalize-space()='"+name+"']") },
	assetPickerAdd       : byCss("[data-testid='dlg-asset-picker'] [data-testid='btn-add']"),
	assetsListItems      : byCss("[data-testid='section-assets'] .asset-row"),

	sectionAttachments   : byCss("[data-testid='section-attachments']"),
	btnAddAttachment     : byCss("[data-testid='section-attachments'] [data-testid='btn-add-attachment']"),
	uploadInputHidden    : byCss("input[type='file'][data-testid='attachment-file']"),
	attachmentsListItems : byCss("[data-testid='section-attachments'] .attachment-row")
]

// ---------- Test Flow ----------
try {
	WebUI.openBrowser("")
	WebUI.maximizeWindow()
	WebUI.navigateToUrl("${baseUrl}/${serviceRequestId}")
	WebUI.waitForPageLoad(20)

	// Header + actions
	WebUI.verifyElementPresent(po.headerSrCurrent, 10)
	WebUI.verifyTextPresent(serviceRequestId, false)
	WebUI.verifyTextPresent(srTitle, false)
	WebUI.verifyElementPresent(po.headerSrDropdown, 5)
	WebUI.verifyElementPresent(po.btnAddNew, 5)
	WebUI.click(po.btnNextAction)
	WebUI.verifyElementVisible(po.nextActionMenu)

	// Requested users
	WebUI.click(po.linkRequestedUsers)
	WebUI.delay(1)
	WebUI.sendKeys(po.linkRequestedUsers, Keys.ESCAPE)

	// Description edit
	WebUI.click(po.descriptionEditIcon)
	WebUI.setText(po.descriptionEditor, newDescription)
	WebUI.click(po.descriptionSave)
	WebUI.verifyTextPresent(newDescription, false)

	// Send Reminder
	WebUI.click(po.sendReminderIcon)
	WebUI.verifyElementVisible(po.sendReminderDialog)
	WebUI.setText(po.sendReminderNote, reminderNote)
	WebUI.click(po.sendReminderSubmit)
	WebUI.verifyElementNotPresent(po.sendReminderDialog, 10)

	// Relations
	WebUI.click(po.relationsAddIcon)
	WebUI.verifyElementVisible(po.relationsDialog)
	WebUI.sendKeys(po.relationsDialog, Keys.ESCAPE)

	// Tabs
	WebUI.verifyElementPresent(po.tabOverview, 5)
	WebUI.verifyElementPresent(po.tabWork, 5)
	WebUI.verifyElementPresent(po.tabCost, 5)
	WebUI.verifyElementPresent(po.tabDivision, 5)
	WebUI.click(po.tabOverview)

	// Location & Space (map + add)
	WebUI.verifyElementPresent(po.sectionLocationSpace, 10)
	WebUI.verifyElementPresent(po.mapCanvasPrimary, 10)
	WebUI.click(po.btnAddLocation)
	WebUI.verifyElementVisible(po.addLocationDialog)
	WebUI.setText(po.addLocationInput, "Arora Room, Room No. 101")
	WebUI.click(po.addLocationSave)
	WebUI.verifyElementNotPresent(po.addLocationDialog, 10)

	// Assets
	WebUI.verifyElementPresent(po.sectionAssets, 10)
	WebUI.verifyElementPresent(po.assetsListItems, 5)
	WebUI.click(po.btnAddAsset)
	WebUI.verifyElementVisible(po.assetPickerDialog)
	WebUI.setText(po.assetPickerSearch, assetToSelect)
	WebUI.click(po.assetPickerOption(assetToSelect))
	WebUI.click(po.assetPickerAdd)
	WebUI.verifyElementNotPresent(po.assetPickerDialog, 10)
	WebUI.verifyTextPresent(assetToSelect, false)

	// Attachments
	WebUI.verifyElementPresent(po.sectionAttachments, 10)
	WebUI.verifyElementPresent(po.attachmentsListItems, 5)
	WebUI.click(po.btnAddAttachment)
	WebUI.uploadFile(po.uploadInputHidden, attachmentPath)
	WebUI.delay(1)
	WebUI.verifyElementPresent(po.attachmentsListItems, 10)

	// Quick tab sweep
	WebUI.click(po.tabWork);     WebUI.delay(1)
	WebUI.click(po.tabCost);     WebUI.delay(1)
	WebUI.click(po.tabDivision); WebUI.delay(1)
	WebUI.click(po.tabOverview)

} finally {
	WebUI.closeBrowser()
}